/*******************************************************
*                                                      *
*   Criado em: Sáb 11/Jun/2016,  13:48 hs              *
*   Instituicao: Universidade Federal do Ceará         *
*   Autor: Iago O. Lima                                *
*   email: iago.oliveira@alu.ufc.br                    *
*                                                      *
********************************************************/


#include "gpioLED.h"
#define MSEG                           (0x3FFFFFF)


int buttonvalue(unsigned int nPinIo){
	int *aux = (int*)(GPIO_INSTANCE_ADDRESS + GPIO_DATAIN);
	int pinvalue = *aux;
	
	if(pinvalue & (1<<nPinIo)){
		return PIN_HIGH;
	}else{
		return PIN_LOW;
	}
}



/*FUNCTION*-------------------------------------------------------
*
* Function Name : main
* Comments      :
*END*-----------------------------------------------------------*/
int main() {
    int portInput = 15;
    int portOutput = 23;
    /* configure gpio pin for the blue LED control. */
    ledInit(portInput, DIR_INPUT);
    ledInit(portOutput, DIR_OUTPUT);

    while(TRUE){
        /* Change the state of the blue LED. */     
        if(buttonvalue(portInput)){
        	GPIOPinWrite(GPIO_INSTANCE_ADDRESS, GPIO_INSTANCE_PIN_NUMBER(portOutput),
                		PIN_HIGH);
        }
        else{
        	GPIOPinWrite(GPIO_INSTANCE_ADDRESS, GPIO_INSTANCE_PIN_NUMBER(portOutput),
                		PIN_LOW);
        }


    }

    return(0);
} 